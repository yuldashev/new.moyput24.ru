$(function(){	
	for(var $i=0;$i<4;$i++){
		init_uploads('photo_'+$i,'/progress/downloads_photo/'+$i+'/');
	}
})