<?php
	class menu extends module{
		
		public $name='Мобильное меню',$module='menu',$link='/menu',$background='background.jpg';
		
		public function menu(){
			$this->init();
		}
		
		public function info(){
		
		}
	}	
?>