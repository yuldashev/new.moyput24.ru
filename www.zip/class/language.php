<?php
	class language{
		public $rus=array();
		public function language(){
			$this->rus['system']					=	'Мой путь';
			$this->rus['title']						=	'Мой путь';
			$this->rus['favicon']					=	'images/favicon.png';
			$this->rus['logo']						=	'images/logo.png';
			$this->rus['base_url']					=	base_url;
			
			$this->rus['bye_title']					=	'Хорошего Вам дня';
			$this->rus['bye_body']					=	'Спасибо за посещение Школы МойПуть. Будем с нетерпением ждать Вас снова.';
			$this->rus['bye_width']					=	'400';
			
			$this->rus['about_title']					=	'О программе';
			$this->rus['about_body']					=	'Раздел находится в разработке.';
			$this->rus['about_width']					=	'400';
			
			$this->rus['help_title']					=	'Помощь';
			$this->rus['help_body']						=	'Раздел находится в разработке.';
			$this->rus['help_width']					=	'600';
			
			$this->rus['contact_title']					=	'Обратная связь';
			$this->rus['contact_body']					=	'Раздел находится в разработке.';
			$this->rus['contact_width']					=	'400';
			
			$this->rus['recipes_title']					=	'Рецепты';
			$this->rus['recipes_body']					=	'Раздел находится в разработке.';
			$this->rus['recipes_width']					=	'600';
			
			$this->rus['showcase_title']					=	'Витрина продуктов Мой Путь';
			$this->rus['showcase_body']						=	'Раздел находится в разработке.';
			$this->rus['showcase_width']					=	'600';
			
			$this->rus['programs_title']					=	'Магазин программ';
			$this->rus['programs_body']						=	'Раздел находится в разработке.';
			$this->rus['programs_width']					=	'600';
			
			$this->rus['stock_title']					=	'Акции';
			$this->rus['stock_body']					=	'Раздел находится в разработке.';
			$this->rus['stock_width']					=	'600';
			
			$this->rus['news_title']					=	'Новости';
			$this->rus['news_body']						=	'Раздел находится в разработке.';
			$this->rus['news_width']					=	'600';
			
			$this->rus['faq_title']						=	'FAQ';
			$this->rus['faq_body']						=	'Раздел находится в разработке.';
			$this->rus['faq_width']						=	'600';
			
			$this->rus['chat_title']					=	'Чат';
			$this->rus['chat_body']						=	'Раздел находится в разработке.';
			$this->rus['chat_width']					=	'600';
			
			
		}
	};
?>