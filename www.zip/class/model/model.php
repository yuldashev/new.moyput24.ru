<?php
	class model extends standard{
		
		public $data;
		
	}
?>