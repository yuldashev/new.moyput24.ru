<?php
	class globals{
		
		public $setting;
		
		public function globals(){
		/*
			$db=new db();
			$db->select('setting','',array());
			$this -> setting = $db ->rows[0];
			*/
			
		}
		
	}
?>